import os
import shutil
import winreg
import ctypes
import psutil
from colorama import Fore, init

# Initialize colorama for colored output
init()

def clear():
    """Clear console screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def info(msg: str) -> None:
    """Print information messages."""
    print(f"{Fore.LIGHTCYAN_EX}[INFO]{Fore.RESET} {msg}")

def error(msg: str) -> None:
    """Print error messages."""
    print(f"{Fore.LIGHTRED_EX}[ERROR]{Fore.RESET} {msg}")

def warning(msg: str) -> None:
    """Print warning messages."""
    print(f"{Fore.LIGHTYELLOW_EX}[INFO]{Fore.RESET} {msg}")

def success(msg: str) -> None:
    """Print success messages."""
    print(f"{Fore.LIGHTGREEN_EX}[INFO]{Fore.RESET} {msg}")

def verbose(msg: str) -> None:
    """Print verbose (debug) messages."""
    print(f"{Fore.LIGHTBLACK_EX}[INFO]{Fore.RESET} {msg}")

def pgisopen() -> bool:
    """Check if Pixel Gun 3D process is running."""
    for proc in psutil.process_iter():
        if proc.name() == "Pixel Gun 3D.exe":
            try:
                return proc.pid > 0
            except:
                pass
    return False

def is_admin():
    """Check if script is running with administrator privileges."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def clean_ban_traces():
    """Perform cleaning of ban traces."""
    completed = 0
    user_ids_str = ""

    clear()
    print("""Ban Trace Cleaner made by: YeetDisDude
    This script does NOT unban you! This only reduces the chances of getting banned when you are creating a new account. It is recommended to use this script before you create a new account.\n""")

    # Check if Pixel Gun 3D is running
    if pgisopen():
        error("Pixel Gun 3D is currently running! Close it and run the ban trace cleaner again.")
        input(f"\n{Fore.LIGHTWHITE_EX}[>>]{Fore.RESET} [{completed} / 2] Press enter to exit...")
        return

    info(f"{Fore.LIGHTCYAN_EX}[1 / 2]{Fore.RESET} Removing {Fore.LIGHTCYAN_EX}LocalLow/Pixel Gun Team{Fore.RESET} directory...")
    appdataDir = os.getenv("APPDATA")
    if not appdataDir:
        error("Error getting appdata path... Exiting")
        input(f"\n{Fore.LIGHTWHITE_EX}[>>]{Fore.RESET} [{completed} / 2] Press enter to exit...")
        return

    localLowDir = os.path.abspath(os.path.join(appdataDir, "..", "LocalLow"))
    pgteamdir = os.path.join(localLowDir, "Pixel Gun Team")
    idDir = os.path.join(pgteamdir, "Pixel Gun 3D", "lobby_textures")
    verbose(f"Pixel Gun Team Directory: {pgteamdir}")

    if os.path.isdir(pgteamdir):
        verbose("Directory Exists! Deleting...")
        try:
            directories = os.listdir(idDir)
            user_ids = [int(d.split("-")[1]) for d in directories if d.startswith("user-")]
            user_ids_str = ", ".join(str(id) for id in user_ids)
        except Exception as e:
            error(f"Failed to get list of IDs, skipping... (Error: {e})")

        try:
            shutil.rmtree(pgteamdir)
            success("Deleted Pixel Gun Team!")
            completed += 1
        except Exception as e:
            error(f"Failed to delete directory, error: {e}")
    else:
        error("This directory was not found, it may have been deleted already! Skipping...")

    info(f"{Fore.LIGHTCYAN_EX}[2 / 2]{Fore.RESET} Removing {Fore.LIGHTCYAN_EX}Registry Keys{Fore.RESET}")
    if not is_admin():
        error("This script is not being run with Administrator Privileges so it is unable to delete registry keys!")
        input(f"\n{Fore.LIGHTWHITE_EX}[>>]{Fore.RESET} [{completed} / 2] Press enter to exit...")
        return

    try:
        pRemTarget = winreg.OpenKeyEx(winreg.HKEY_CURRENT_USER, "Software\\Pixel Gun Team")
        try:
            winreg.OpenKey(pRemTarget, "Pixel Gun 3D")
            winreg.DeleteKey(pRemTarget, "Pixel Gun 3D")
            success("Deleted Pixel Gun Team Registry keys!")
            completed += 1
        except Exception as e:
            error("The registry keys were not found, they may have been deleted already! Skipping...")
    except Exception as e:
        error(f"Error when deleting keys: {e}")

    print("\n")
    success(f"Traces found: {user_ids_str}")
    input(f"{Fore.LIGHTWHITE_EX}[>>]{Fore.RESET} [{completed} / 2] Finished cleaning ban traces! Press enter to exit...")

if __name__ == "__main__":
    clean_ban_traces()
