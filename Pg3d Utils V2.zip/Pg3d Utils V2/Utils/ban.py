import random
import httpx

def check_ban():
    usrid = input("Enter User ID: ")
    print(f"Status: Sending Request to Pixel Gun 3D Servers...")

    # Make sure usrid is converted to an integer
    try:
        usrid = int(usrid)
    except ValueError:
        print("Error: Please enter a valid integer for User ID.")
        return

    response = httpx.post("https://secure.pixelgunserver.com/pixelgun3d-config/getBanList.php", 
                          data={'type_device': int(random.random() * 69), 'id': usrid}).text
    
    if response == "1":
        print(f"Status: User ID {usrid} is banned!")
    else:
        print(f"Status: User ID {usrid} is not banned.")

if __name__ == "__main__":
    check_ban()